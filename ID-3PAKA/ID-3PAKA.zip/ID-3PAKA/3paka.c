//gcc -o 3paka_1 3paka.c -lgmp -I/Users/nimishmishra/Documents/GitHub/ecc-core/pbc_install/include -lpbc
// ./3paka_1 < /Users/nimishmishra/Documents/GitHub/ecc-core/pbc-0.5.14/param/a.param

#include "pbc.h"
#include <stdint.h>
#include <stdio.h>
#define SUCCESS 0
#define FAILURE -1

void initialize_pairing(pairing_t* pairing, 
    char pairing_parameters[1024], 
    size_t* param_len){
        pairing_init_set_buf(*pairing, pairing_parameters, *param_len);
}

void print_pairing_sizes(pairing_t* pairing){
    printf("--------- Verifying Pairing properties -----------\n");
    printf("[DEBUG] Pairing is symmetric: %s\n",(pairing_is_symmetric(*pairing)? "TRUE": "FALSE"));
    printf("[DEBUG] Group G1 bit size: %d\n", (pairing_length_in_bytes_G1(*pairing) * 8));
    printf("[DEBUG] Group G2 bit size: %d\n", (pairing_length_in_bytes_G2(*pairing) * 8));
    printf("[DEBUG] Group GT bit size: %d\n", (pairing_length_in_bytes_GT(*pairing) * 8));
    printf("[DEBUG] Group Zr bit size: %d\n", (pairing_length_in_bytes_Zr(*pairing) * 8));
}

void print_system_parameters(
    element_t master_secret_key, 
    element_t group_generator, 
    element_t master_public_key
){
    printf("--------- Verifying private-public relationship -----------\n");
    element_printf("[DEBUG] Master secret key: %B\n\n", master_secret_key);
    element_printf("[DEBUG] Group generator: %B\n\n", group_generator);
    element_printf("[DEBUG] Master public key: %B\n\n", master_public_key);
}

void extract_identity_based_private_key(
    element_t* identity_based_private_key,
    pairing_t* pairing,
    element_t* master_secret_key,
    element_t* group_generator
    ){
    printf("--------------------- EXTRACTION PHASE -------------------------\n");
    char IDENTITY[20] = "user 1";
    element_t hashed_group_element;
    element_t intermediate_element;


    element_init_G1(hashed_group_element, *pairing);
    element_init_G1(intermediate_element, *pairing);
    element_init_G1(*identity_based_private_key, *pairing);

    element_from_hash(hashed_group_element, (void*) IDENTITY, sizeof(IDENTITY)); // computing q_i
    element_printf("[DEBUG] Hashed group point: %B\n", hashed_group_element);
    element_add(intermediate_element, *master_secret_key, hashed_group_element); // computing s + q_i
    element_div(intermediate_element, *master_secret_key, intermediate_element); // computing s/(s + q_i)
    element_mul(*identity_based_private_key, *group_generator, intermediate_element); // Element wise multiplication, needs to be verified
}

void generate_signature(element_t* psi_1, 
    element_t* sigma_1, 
    pairing_t* pairing, 
    element_t* group_generator, 
    element_t* identity_based_private_key){
        
        printf("------------------ SIGNATURE PHASE ----------------------------\n");
        element_t randomness;
        element_init_Zr(randomness, *pairing);
        element_init_G2(*psi_1, *pairing);
        element_init_G2(*sigma_1, *pairing);

        element_random(randomness); // filling in r1
        element_printf("[DEBUG] Chosen randomness: %B\n", randomness);
        element_mul_zn(*psi_1, *group_generator, randomness); // PSI_1 = r1.P
        element_mul_zn(*sigma_1, *identity_based_private_key, randomness); // SIGMA_1 = r1.d1
    }

int main(){

    //////////////// SETUP PHASE //////////////////////////////////
    pairing_t pairing;
    char pairing_parameters[1024];
    size_t param_len = fread(pairing_parameters, 1, 1024, stdin);
    if(!param_len){
        printf("Failure in reading input");
        return FAILURE;
    }
    initialize_pairing(&pairing, pairing_parameters, &param_len);
    print_pairing_sizes(&pairing);
    
    element_t master_secret_key;
    element_t group_generator;
    element_t master_public_key;
    mpz_t mpz_representation_of_master_secret_key;

    element_init_G2(group_generator, pairing);
    element_init_G2(master_public_key, pairing);
    element_init_Zr(master_secret_key, pairing);

    element_random(group_generator);
    element_random(master_secret_key);
    element_to_mpz(mpz_representation_of_master_secret_key, master_secret_key);
    element_mul_zn(master_public_key, group_generator, master_secret_key);

    print_system_parameters(master_secret_key, group_generator, master_public_key);
    //////////////////////////////////////////////////////////////


    //////////////// EXTRACTION PHASE ////////////////////////////
    element_t identity_based_private_key;
    extract_identity_based_private_key(&identity_based_private_key, &pairing, &master_secret_key, &group_generator);
    element_printf("[DEBUG] Identity based private key: %B\n", identity_based_private_key);
    //////////////////////////////////////////////////////////////

    //////////////// SIGNATURE PHASE /////////////////////////////
    element_t psi_1;
    element_t sigma_1;
    generate_signature(&psi_1, &sigma_1, &pairing, &group_generator, &identity_based_private_key);
    element_printf("[DEBUG] Psi 1: %B\n", psi_1);
    element_printf("[DEBUG] Sigma 1: %B\n", sigma_1);
    //////////////////////////////////////////////////////////////
    return SUCCESS;
}